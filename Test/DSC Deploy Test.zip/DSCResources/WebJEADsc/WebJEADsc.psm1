$resourceFiles = @(
    'IISAppPool'
)

foreach ($resource in $resourceFiles)
{
    . (Join-Path $PSScriptRoot "Resources\$resource.ps1")
}
