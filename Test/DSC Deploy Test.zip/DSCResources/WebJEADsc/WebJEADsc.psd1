@{
    RootModule        = 'WebJEADsc.psm1'
    ModuleVersion     = '1.0.0'
    GUID              = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
    Author            = 'WebJEA'
    Description       = 'DSC resources for WebJEA deployment (IIS app pool)'
    PowerShellVersion = '5.1'

    DscResourcesToExport = @(
        'IISAppPool'
    )
}
