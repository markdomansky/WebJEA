[DscResource()]
class IISAppPool
{
    [DscProperty(Key)]
    [string] $Name

    [DscProperty()]
    [string] $Ensure = 'Present'

    [DscProperty()]
    [string] $State = 'Started'

    # 'SpecificUser' | 'ApplicationPoolIdentity' | 'LocalSystem' | 'LocalService' | 'NetworkService'
    [DscProperty()]
    [string] $IdentityType = 'ApplicationPoolIdentity'

    [DscProperty()]
    [string] $UserName = ''

    [DscProperty()]
    [string] $Password = ''

    [DscProperty()]
    [string] $ManagedRuntimeVersion = 'v4.0'

    [DscProperty()]
    [bool] $LoadUserProfile = $false

    [DscProperty()]
    [bool] $AutoStart = $true

    [DscProperty()]
    [string] $ManagedPipelineMode = 'Integrated'

    [IISAppPool] Get()
    {
        $result = [IISAppPool]::new()
        $result.Name = $this.Name

        Import-Module WebAdministration -Verbose:$false
        $pool = Get-Item "IIS:\AppPools\$($this.Name)" -ErrorAction SilentlyContinue
        if ($null -eq $pool)
        {
            $result.Ensure = 'Absent'
            return $result
        }

        $result.Ensure = 'Present'
        $result.State = if ($pool.State -eq 'Started') { 'Started' } else { 'Stopped' }
        $result.ManagedRuntimeVersion = $pool.managedRuntimeVersion
        $result.ManagedPipelineMode = $pool.managedPipelineMode
        $result.LoadUserProfile = [bool]$pool.processModel.loadUserProfile
        $result.AutoStart = [bool]$pool.autoStart
        $result.IdentityType = $pool.processModel.identityType
        $result.UserName = $pool.processModel.userName
        return $result
    }

    [bool] Test()
    {
        Import-Module WebAdministration -Verbose:$false
        $pool = Get-Item "IIS:\AppPools\$($this.Name)" -ErrorAction SilentlyContinue

        if ($this.Ensure -eq 'Absent')
        {
            return ($null -eq $pool)
        }
        if ($null -eq $pool) { return $false }

        if ($pool.managedRuntimeVersion -ne $this.ManagedRuntimeVersion) { return $false }
        if ($pool.managedPipelineMode -ne $this.ManagedPipelineMode) { return $false }
        if ([bool]$pool.processModel.loadUserProfile -ne $this.LoadUserProfile) { return $false }
        if ([bool]$pool.autoStart -ne $this.AutoStart) { return $false }

        if ($this.IdentityType -eq 'SpecificUser')
        {
            if ($pool.processModel.userName -ne $this.UserName) { return $false }
        }
        else
        {
            if ($pool.processModel.identityType -ne $this.IdentityType) { return $false }
        }

        $currentState = if ($pool.State -eq 'Started') { 'Started' } else { 'Stopped' }
        if ($currentState -ne $this.State) { return $false }

        return $true
    }

    [void] Set()
    {
        Import-Module WebAdministration -Verbose:$false
        $pool = Get-Item "IIS:\AppPools\$($this.Name)" -ErrorAction SilentlyContinue

        if ($this.Ensure -eq 'Absent')
        {
            if ($null -ne $pool)
            {
                Remove-WebAppPool -Name $this.Name
            }
            return
        }

        if ($null -eq $pool)
        {
            New-WebAppPool -Name $this.Name
            $pool = Get-Item "IIS:\AppPools\$($this.Name)"
        }

        Set-ItemProperty "IIS:\AppPools\$($this.Name)" -Name managedRuntimeVersion -Value $this.ManagedRuntimeVersion
        Set-ItemProperty "IIS:\AppPools\$($this.Name)" -Name managedPipelineMode -Value $this.ManagedPipelineMode
        Set-ItemProperty "IIS:\AppPools\$($this.Name)" -Name autoStart -Value $this.AutoStart

        $pool = Get-Item "IIS:\AppPools\$($this.Name)"
        $pool.processModel.loadUserProfile = $this.LoadUserProfile

        if ($this.IdentityType -eq 'SpecificUser')
        {
            $pool.processModel.identityType = 'SpecificUser'
            $pool.processModel.userName = $this.UserName
            # gMSA accounts use an empty password; regular accounts supply the password
            $pool.processModel.password = $this.Password
        }
        else
        {
            $pool.processModel.identityType = $this.IdentityType
            $pool.processModel.userName = ''
            $pool.processModel.password = ''
        }
        $pool | Set-Item

        $currentState = (Get-Item "IIS:\AppPools\$($this.Name)").State
        if ($this.State -eq 'Started' -and $currentState -ne 'Started')
        {
            Start-WebAppPool -Name $this.Name
        }
        elseif ($this.State -eq 'Stopped' -and $currentState -ne 'Stopped')
        {
            Stop-WebAppPool -Name $this.Name
        }
    }
}
