<#
.SYNOPSIS
    WebJEA deployment script using Microsoft DSC v3.

.DESCRIPTION
    Deploys WebJEA to an IIS server using Microsoft DSC v3 (dsc.exe) for idempotent configuration.
    The deployment mode is auto-detected from the settings file:
    if SubModuleName is present, SubModule mode is used; otherwise Root mode.

.PARAMETER SettingsFile
    Path to the settings file. Use settings-root.template.jsonc for root site deployments
    and settings-submodule.template.jsonc for per-gMSA sub-module deployments.

.PARAMETER TestOnly
    Run dsc config test instead of set (validate without making changes).

.EXAMPLE
    .\DeployV3.ps1 -SettingsFile .\settings-root.json
    .\DeployV3.ps1 -SettingsFile .\settings-submodule.json
    .\DeployV3.ps1 -SettingsFile .\settings-root.json -TestOnly
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [string] $SettingsFile,

    [switch] $TestOnly
)
begin
{
    Set-StrictMode -Version Latest
    $ErrorActionPreference = 'Stop'

    $MinDSCVersion = [version]'3.2.0'

    # ---------------------------------------------------------------------------
    #region  Helpers
    # ---------------------------------------------------------------------------

    function WriteStatus
    {
        param([string]$Message, [string]$Status = 'INFO', [ConsoleColor]$Color = [ConsoleColor]::Cyan)
        $prefix = switch ($Status) { 'OK' { '[  OK  ]' } 'FAIL' { '[FAILED]' } 'WARN' { '[ WARN ]' } default { '[ INFO ]' } }
        Write-Host "$prefix $Message" -ForegroundColor $Color
    }

    function GetSettingsFile
    {
        param([string]$Path)
        if (-not (Test-Path $Path)) { throw "Settings file not found: $Path" }
        #PS5.1 doesn't support ConvertFrom-Json with comments, so we strip out lines starting with // before parsing.
        Write-Verbose ('Reading settings file: {0}' -f $Path)
        $raw = (Get-Content $Path)
        $trimmed = $raw | Where-Object { $_ -notmatch '^\s*\/\/' }
        try { $settings = $trimmed | ConvertFrom-Json } catch { Write-Verbose "Failed to parse JSON from $($Path): $($_.Exception.Message)"; throw }
        Write-Verbose ('Loaded settings keys: {0}' -f (($settings | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name) -join ','))
        return $settings
    }

    function InvokeStep([psobject]$Step, [switch]$TestOnly)
    {
        Write-Verbose ('InvokeStep: {0}' -f ($Step.Description -or '<no description>'))
        if ($Step.TestScript) { Write-Verbose ' - TestScript present' }
        if ($Step.SetScript) { Write-Verbose ' - SetScript present' }
        if (-not $step.description)
        {
            WriteStatus "Error with configuration: $($Step | ConvertTo-Json -Depth 2)" -ForegroundColor Yellow
            return
        }
        if ($step.description -and -not ($step.testscript -or $step.module))
        {
            WriteStatus $($Step.Description) -ForegroundColor Cyan
        }
        else
        {
            WriteStatus "> $($Step.Description)" -ForegroundColor Cyan
        }

        if ($Step.TestScript -and $Step.SetScript)
        {
            ##### Custom Script Resource
            Write-Verbose "  Test: $($Step.TestScript.ToString())"
            if ($Step.testscript -is [string]) { $Step.TestScript = [scriptblock]::Create($Step.TestScript) }
            if ($Step.setscript -is [string]) { $Step.SetScript = [scriptblock]::Create($Step.SetScript) }

            $step.InDesiredState = & $Step.TestScript
            Write-Verbose ('  TestScript result: {0}' -f $step.InDesiredState)
            if (-not $step.InDesiredState -and -not $TestOnly -and $Step.SetScript)
            {
                WriteStatus '  [SET] not in desired state. Updating...' -ForegroundColor Cyan
                Write-Verbose "  Set: $($Step.SetScript.ToString())"
                $set = & $Step.SetScript
                $step.InDesiredState = & $Step.TestScript
                Write-Verbose ('  Post-Set TestScript result: {0}' -f $step.InDesiredState)
            }
        }
        elseif (-not $Step.TestScript -and -not $Step.SetScript)
        {
            #Empty step, do nothing
            Write-Verbose 'No TestScript/SetScript specified for this step. Skipping.'
        }
        else
        {
            Write-Verbose ($step | ConvertTo-Json -Depth 2)
            throw "Invalid resource step: $($Step | ConvertTo-Json -Depth 2)"
        }

        if ($step.InDesiredState)
        {
            WriteStatus '  [OK] in desired state.' -ForegroundColor Green
        }
        else
        {
            WriteStatus '  [FAILED] still not in desired state after Set.' -ForegroundColor Red
            if (-not $TestOnly) { throw "step '$Description' failed to reach desired state." }
        }
    }
    #endregion

    # ---------------------------------------------------------------------------
    #region  Phase 1 — Bootstrap: ensure dsc.exe is available
    # ---------------------------------------------------------------------------

    function GetBootstrapSteps
    {
        Write-Verbose 'Building bootstrap steps.'
        #Install DSC v3
        Write-Output @{
            Description = 'Ensuring DSC v3 (dsc.exe) is available...'
            TestScript  = {
                $DSCCmd = Get-Command 'dsc.exe' -ErrorAction SilentlyContinue
                if (-not $DSCCmd) { return $false }
                $installedVersion = [version]((& $dscCmd.Source --version 2>&1) -replace '.*(\d+\.\d+\.\d+).*', '$1')
                return ($installedVersion -ge $MinDSCVersion)
            }
            SetScript   = {
                $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/PowerShell/DSC/releases/latest' -UseBasicParsing
                $latestVersion = [version]($release.tag_name -replace '^v')
                WriteStatus "Latest DSC v3 release: $latestVersion"

                $asset = $release.assets | Where-Object { $_.name -like '*.msixbundle' } | Select-Object -First 1
                if (-not $asset) { $asset = $release.assets | Where-Object { $_.name -like '*x86_64*windows*.msix' } | Select-Object -First 1 }
                if (-not $asset) { throw 'Could not find a Windows MSIXBundle or MSIX DSC asset in the latest GitHub release.' }

                $msixPath = Join-Path $env:TEMP $asset.name
                WriteStatus "Downloading $($asset.name)..."
                Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $msixPath -UseBasicParsing

                WriteStatus 'Installing DSC v3 via MSIX package...'
                Add-AppxPackage -Path $msixPath -ForceApplicationShutdown
                Remove-Item $msixPath -Force

                # Refresh process PATH so the MSIX-registered dsc.exe is immediately discoverable.
                $env:PATH = [System.Environment]::GetEnvironmentVariable('PATH', 'Machine') + ';' +
                            [System.Environment]::GetEnvironmentVariable('PATH', 'User')

                $dscCmd = Get-Command 'dsc.exe' -ErrorAction SilentlyContinue
                if (-not $dscCmd) { throw 'DSC v3 MSIX installation completed but dsc.exe was not found in PATH. A new shell session may be required.' }
                WriteStatus "DSC v3 $latestVersion installed successfully." -Status 'OK' -Color Green
            }
        }

        Write-Output @{
            Description = 'WinRM Service - StartupType=Automatic'
            TestScript  = {
                $svc = Get-Service -Name WinRM -ErrorAction SilentlyContinue
                return ($null -ne $svc -and $svc.StartType -eq 'Automatic')
            }
            SetScript   = {
                Set-Service -Name WinRM -StartupType Automatic
            }
        }

        Write-Output @{
            Description = 'WinRM Service - Running'
            TestScript  = {
                $svc = Get-Service -Name WinRM -ErrorAction SilentlyContinue
                return ($null -ne $svc -and $svc.Status -eq 'Running')
            }
            SetScript   = {
                Start-Service -Name WinRM
            }
        }

        Write-Output @{
            Description = 'WinRM HTTP Listener exists'
            TestScript  = {
                $listeners = @(Get-WSManInstance -ResourceURI winrm/config/Listener -Enumerate -ErrorAction SilentlyContinue)
                return ($listeners.Count -gt 0)
            }
            SetScript   = {
                winrm quickconfig -quiet -force 2>&1 | Out-Null
            }
        }

        Write-Output @{
            Description = 'Nuget provider is current (>= 2.8.5.201)'
            TestScript  = {
                $nuget = Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue
                return ($null -ne $nuget -and [version]$nuget.Version -ge [version]'2.8.5.201')
            }
            SetScript   = {
                Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope AllUsers | Out-Null
            }
        }

        Write-Output @{
            Description = 'PowerShellGet is current (>= 2.2.5)'
            TestScript  = {
                $psg = Get-Module -Name PowerShellGet -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
                return ($null -ne $psg -and [version]$psg.Version -ge [version]'2.2.5')
            }
            SetScript   = {
                Install-Module -Name PowerShellGet -MinimumVersion 2.2.5 -Force -AllowClobber -Scope AllUsers
            }
        }

        Write-Output @{
            Description = 'PowerShell Gallery is a trusted repository'
            TestScript  = {
                $repo = Get-PSRepository -Name PSGallery -ErrorAction SilentlyContinue
                return ($repo -and $repo.InstallationPolicy -eq 'Trusted')
            }
            SetScript   = {
                Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
            }
        }

        $requiredModules = @(
            @{ Name = 'WebAdministrationDsc'; MinimumVersion = '4.2.1' }
            @{ Name = 'xXMLConfigFile'; MinimumVersion = '2.0.0.3' }
            @{ Name = 'SecurityPolicyDsc'; MinimumVersion = '2.10.0.0' }
            @{ Name = 'xRobocopy'; MinimumVersion = '2.0.0.0' }
            @{ Name = 'DSCR_FileContent'; MinimumVersion = '3.0.2' }
        )

        foreach ($mod in $requiredModules)
        {
            Write-Output @{
                Description = "Module $($mod.Name) v$($mod.MinimumVersion)+ is installed"
                TestScript  = {
                    $installed = Get-Module -Name $mod.Name -ListAvailable -ErrorAction SilentlyContinue |
                        Sort-Object Version -Descending | Select-Object -First 1
                    return ($null -ne $installed -and [version]$installed.Version -ge [version]$mod.MinimumVersion)
                }.GetNewClosure()
                SetScript   = {
                    Install-Module -Name $mod.Name -MinimumVersion $mod.MinimumVersion -Force -AllowClobber -Scope AllUsers
                }.GetNewClosure()
            }
        }


    }
    # # Make WebJEADsc discoverable by the Windows PowerShell adapter
    # $dscResourcesPath = Join-Path $PSScriptRoot 'DSCResources'
    # if ($env:PSModulePath -notlike "*$dscResourcesPath*")
    # {
    #     $env:PSModulePath = "$dscResourcesPath;$env:PSModulePath"
    # }

    #endregion

    # ---------------------------------------------------------------------------
    #region  Phase 3 — Config document generation
    # ---------------------------------------------------------------------------

    function BuildConfigParameters
    {
        param([psobject] $Settings)

        $siteName = [string]$Settings.SiteName
        $sitePath = [string]$Settings.SitePath
        $scriptsPath = [string]$Settings.ScriptsPath
        $siteFqdn = ''
        if ($Settings.SiteFQDN) { $siteFQDN = [string]$Settings.SiteFQDN }
        $subModuleName = ''
        try { $subModuleName = [string]$Settings.SubModuleName } catch { }
        $AppPoolIdentityType = 'ApplicationPoolIdentity'
        if ($Settings.AppPoolUserName) { $AppPoolIdentityType = 'SpecificUser' }
        $AppPoolPassword = ''
        if ($Settings.AppPoolPassword) { $AppPoolPassword = [string]$Settings.AppPoolPassword }
        $CertThumbprint = ''
        if ($Settings.CertThumbprint) { $CertThumbprint = [string]$Settings.CertThumbprint -replace '\s+', '' }
        Write-Verbose ('Building config parameters for site: {0}' -f $siteName)
        Write-Verbose (' - SitePath: {0}, ScriptsPath: {1}, SiteFQDN: {2}' -f $sitePath, $scriptsPath, $siteFqdn)

        $config = [ordered]@{
            AppPoolName                 = [string]$Settings.AppPoolName
            AppPoolLoadUserProfile      = [bool]($Settings.AppPoolLoadUserProfile -eq $true)
            AppPoolIdentityType         = $AppPoolIdentityType
            AppPoolUserName             = [string]$Settings.AppPoolUserName
            AppPoolPassword             = $AppPoolPassword
            SiteName                    = $siteName
            SitePath                    = $sitePath
            SiteIISPath                 = "IIS:\Sites\$siteName"
            SiteFQDN                    = $siteFqdn
            CertThumbprint              = $certThumbprint
            HTTPSRedirectActionUrl      = "https://$siteFqdn/{R:1}"
            DisableDefaultWebsite       = [bool]($Settings.DisableDefaultWebsite -eq $true)
            RedirectPort80To443         = [bool]($Settings.RedirectPort80To443 -eq $true)
            EnableBackwardCompatibility = [bool]($Settings.EnableBackwardCompatibility -eq $true)
            # ScriptsPath                 = $scriptsPath #can't pass unmapped variables
            ScriptsPathJsonValue        = ($scriptsPath | ConvertTo-Json -Compress)
            ScriptsConfigJson           = Join-Path $scriptsPath 'config.json'
            WebConfigPath               = Join-Path $sitePath 'Web.config'
            NLogConfigPath              = Join-Path $sitePath 'NLog.config'
            LogFile                     = [string]$Settings.LogFile
            LogUsageFile                = [string]$Settings.LogUsageFile
            # SubModuleName               = $subModuleName
            SourcePath                  = $PSScriptRoot
            # StarterScriptsSourcePath    = Join-Path $PSScriptRoot 'TestScripts'
        }
        if ($subModuleName)
        {
            $config.SubModuleName = $subModuleName
        }
        return $config
    }


    #endregion

    # ---------------------------------------------------------------------------
    #region  Phase 4 — Invoke DSC and render results
    # ---------------------------------------------------------------------------

    function InvokeDSCDocument
    {
        param(
            [string]    $DocumentPath,
            [hashtable] $Parameters = @{},
            [switch]    $TestOnly
        )

        Write-Verbose ('InvokeDSCDocument: {0} (TestOnly={1})' -f $DocumentPath, [bool]$TestOnly)
        # Serialise DSC parameters to a temp JSON file for --parameters-file.
        $paramsPath = Join-Path $env:TEMP 'dsc_params.json'
        $paramsPayload = [ordered]@{ parameters = [ordered]@{} }
        foreach ($key in $Parameters.Keys)
        {
            $paramsPayload.parameters[$key] = [ordered]@{ value = $Parameters[$key] }
        }
        try
        {
            $jsonParams = $paramsPayload | ConvertTo-Json -Depth 5
            # Mask AppPoolPassword if present
            $jsonParamsMasked = $jsonParams -replace '"AppPoolPassword"\s*:\s*".*?"', '"AppPoolPassword":"***"'
            $jsonParamsMasked | Set-Content -Path $paramsPath -Encoding UTF8
            Write-Verbose ('Wrote DSC parameters to: {0}' -f $paramsPath)
        }
        catch { Write-Verbose "Failed to serialise DSC parameters: $($_.Exception.Message)"; throw }

        #Ensure DSC_RESOURCE_PATH includes the custom resources
        $dscResourcesPaths = @((Join-Path $psscriptroot 'DSCResources'))
        foreach ($dscResourcesPath in $dscResourcesPaths)
        {
            if ($env:DSC_RESOURCE_PATH -notlike "*$dscResourcesPath*")
            {
                $env:DSC_RESOURCE_PATH = "$dscResourcesPath;$env:DSC_RESOURCE_PATH"
                Write-Verbose "Updated DSC_RESOURCE_PATH to include custom resources: $dscResourcesPath"
            }
        }

        $verb = 'set'
        if ($TestOnly) { $verb = 'test' }
        WriteStatus "Running: dsc config --parameters-file `"$paramsPath`" $verb --file `"$DocumentPath`"" # --output-format json

        # Resolve dsc.exe: prefer the one on PATH, fallback to $env:TEMP\DSC\dsc.exe
        $dscCmd = Get-Command 'dsc.exe' -ErrorAction SilentlyContinue
        if ($dscCmd)
        {
            $dscPath = $dscCmd.Source
        }
        else
        {
            throw 'dsc.exe not found in PATH. Ensure DSC v3 is installed (run the bootstrap step first).'
        }
        Write-Verbose "Using dsc.exe at: $dscPath"
        $stdoutPath = Join-Path $env:TEMP 'dsc_stdout.txt'
        $stderrPath = Join-Path $env:TEMP 'dsc_stderr.txt'

        $proc = Start-Process -FilePath $dscPath `
            -ArgumentList "config --parameters-file `"$paramsPath`" $verb --file `"$DocumentPath`"" `
            -RedirectStandardOutput $stdoutPath `
            -RedirectStandardError $stderrPath `
            -NoNewWindow -Wait -PassThru # --output-format json

        $stdout = Get-Content (Join-Path $env:TEMP 'dsc_stdout.txt') -Raw -ErrorAction SilentlyContinue
        $stderr = Get-Content (Join-Path $env:TEMP 'dsc_stderr.txt') -Raw -ErrorAction SilentlyContinue

        if ($stderr -and $stderr.Trim())
        {
            Write-Host $stderr -ForegroundColor DarkYellow
        }

        $failCount = 0
        $passCount = 0

        if ($stdout)
        {
            # dsc.exe outputs newline-delimited JSON objects
            foreach ($line in ($stdout -split "`n"))
            {
                $trimmed = $line.Trim()
                if (-not $trimmed) { continue }
                try
                {
                    $obj = $trimmed | ConvertFrom-Json -ErrorAction Stop

                    # Extract resource name and result
                    $name = 'Unknown'
                    if ($obj.name) { $name = $obj.name }
                    elseif ($obj.metadata.name) { $name = $obj.metadata.name }

                    $inDesiredState = $null

                    if ($TestOnly)
                    {
                        if ($null -ne $obj.result.inDesiredState) { $inDesiredState = [bool]$obj.result.inDesiredState }
                        elseif ($null -ne $obj.inDesiredState) { $inDesiredState = [bool]$obj.inDesiredState }
                    }
                    else
                    {
                        # 'set' results: check changedAt or beforeState/afterState
                        if ($null -ne $obj.result.changedAt -or $null -ne $obj.changedAt)
                        {
                            $inDesiredState = $true
                        }
                        elseif ($obj.messages)
                        {
                            $inDesiredState = $true
                        }
                        else
                        {
                            $inDesiredState = ($proc.ExitCode -eq 0)
                        }
                    }

                    if ($null -ne $inDesiredState)
                    {
                        if ($inDesiredState)
                        {
                            $passCount++
                            WriteStatus $name -Status 'OK' -Color Green
                            Write-Verbose ('Resource {0} reported InDesiredState=true' -f $name)
                        }
                        else
                        {
                            $failCount++
                            WriteStatus $name -Status 'FAIL' -Color Red
                            Write-Verbose ('Resource {0} reported InDesiredState=false' -f $name)
                        }
                    }
                    else
                    {
                        Write-Host "  $name" -ForegroundColor Gray
                    }
                }
                catch
                {
                    # Not a JSON line — print as-is (informational dsc.exe output)
                    if ($trimmed) { Write-Host "  $trimmed" -ForegroundColor Gray }
                }
            }
        }

        Write-Host ''
        Write-Host "Results: $passCount passed, $failCount failed." -ForegroundColor (if ($failCount -eq 0) { 'Green' } else { 'Red' })

        if ($proc.ExitCode -ne 0 -and -not $TestOnly)
        {
            throw "dsc config set failed (exit code $($proc.ExitCode))."
        }

        return @{ PassCount = $passCount; FailCount = $failCount; ExitCode = $proc.ExitCode }
    }

    #endregion

    # ---------------------------------------------------------------------------
    #region  ValidateSettings
    # ---------------------------------------------------------------------------

    function ValidateSettings
    {
        param([psobject] $Settings, [bool] $IsSubModule = $false)

        $errors = [System.Collections.Generic.List[string]]::new()

        if ($IsSubModule)
        {
            if (-not $Settings.SiteName) { $errors.Add('SiteName is required for sub-module.') }
            if (-not $Settings.SubModuleName) { $errors.Add('SubModuleName is required for sub-module.') }
            if ($settings.SubModuleName -eq 'WebJEA') { $errors.Add('SubModuleName cannot be "WebJEA" (reserved).') }
        }
        else
        {
            if (-not $Settings.SiteName) { $errors.Add('SiteName is required.') }
            if (-not $Settings.SiteFQDN) { $errors.Add('SiteFQDN is required.') }
        }

        if (-not $Settings.SitePath) { $errors.Add('SitePath is required.') }
        if (-not $Settings.AppPoolName) { $errors.Add('AppPoolName is required.') }
        if (-not $Settings.ScriptsPath) { $errors.Add('ScriptsPath is required.') }
        if (-not $Settings.LogFile) { $errors.Add('LogFile is required.') }
        if (-not $Settings.LogUsageFile) { $errors.Add('LogUsageFile is required.') }

        # gMSA detection: username ends with '$'
        if ($Settings.AppPoolUserName -and $Settings.AppPoolUserName.EndsWith('$'))
        {
            if ($Settings.AppPoolPassword)
            {
                $errors.Add("AppPoolPassword must be empty for gMSA accounts (account name ends with `$).")
            }
            # Optional AD check — warn only if RSAT unavailable
            try
            {
                Import-Module ActiveDirectory -ErrorAction Stop -Verbose:$false
                $acctName = $Settings.AppPoolUserName.TrimEnd('$')
                $gmsaCheck = Get-ADServiceAccount -Identity $acctName -ErrorAction SilentlyContinue
                if ($null -eq $gmsaCheck)
                {
                    WriteStatus "gMSA account '$acctName' not found in AD." -Status 'WARN' -Color Yellow
                }
            }
            catch
            {
                WriteStatus 'ActiveDirectory module not available — skipping gMSA AD validation.' -Status 'WARN' -Color Yellow
            }
        }
        elseif ($Settings.AppPoolUserName -and -not $Settings.AppPoolPassword)
        {
            WriteStatus "AppPoolPassword is empty for non-gMSA account '$($Settings.AppPoolUserName)'." -Status 'WARN' -Color Yellow
        }

        if ($Settings.SitePath -and $Settings.ScriptsPath -and
            ($Settings.SitePath.TrimEnd('\') -eq $Settings.ScriptsPath.TrimEnd('\')))
        {
            $errors.Add('SitePath and ScriptsPath must be different directories.')
        }

        if ($Settings.CertThumbprint -and $Settings.CertThumbprint -notmatch '^[0-9A-Fa-f\s]{40,}$')
        {
            $errors.Add('CertThumbprint does not appear to be a valid hex thumbprint.')
        }

        if ($errors.Count -gt 0)
        {
            throw "Settings validation failed:`n" + ($errors -join "`n")
        }
        WriteStatus 'Settings validated.' -Status 'OK' -Color Green
    }

    #endregion

}
process
{
    #region *PROCESS*

    $SettingsFile = Resolve-Path $SettingsFile
    $settings = GetSettingsFile -Path $SettingsFile

    # Verbose: show loaded settings, but mask sensitive fields (AppPoolPassword)
    try
    {
        $settingsJson = $settings | ConvertTo-Json -Depth 6
        if ($settingsJson -match '"AppPoolPassword"\s*:\s*"') { $settingsJson = $settingsJson -replace '"AppPoolPassword"\s*:\s*".*?"', '"AppPoolPassword":"***"' }
        Write-Verbose ("Loaded settings from {0}`n{1}" -f $SettingsFile, $settingsJson)
    }
    catch
    {
        Write-Verbose ('Loaded settings from {0} (unable to serialize settings for verbose output).' -f $SettingsFile)
    }

    try { $isSubModule = -not [string]::IsNullOrWhiteSpace($settings.SubModuleName) } catch { $isSubModule = $false }
    $DeploymentMode = 'Root'
    if ($isSubModule) { $DeploymentMode = 'Sub-Module' }
    Write-Verbose ('Detected deployment mode: {0}' -f $DeploymentMode)

    Write-Verbose 'Validating settings...'
    ValidateSettings -Settings $settings -IsSubModule $isSubModule

    # --- Bootstrap ---
    $BootstrapSteps = GetBootstrapSteps
    Write-Verbose ('Bootstrap steps: {0}' -f $BootstrapSteps.Count)
    foreach ($s in $BootstrapSteps) { Write-Verbose (' - {0}' -f $s.Description) }
    foreach ($step in $BootstrapSteps) { InvokeStep -Step $step -TestOnly:$TestOnly }

    # Using template files directly; no temporary DSC document required.

    try
    {
        if ($isSubModule)
        {
            Write-Host ''
            Write-Host '===  Sub-Module Deployment  ===' -ForegroundColor Cyan

            $templatePath = Join-Path $PSScriptRoot 'DSCConfig\submodule-config.yaml'
        }
        else
        {
            Write-Host ''
            Write-Host '===  Root Deployment  ===' -ForegroundColor Cyan

            $templatePath = Join-Path $PSScriptRoot 'DSCConfig\root-config.yaml'
        }

        Write-Verbose ('Using DSC document: {0}' -f $templatePath)

        $params = BuildConfigParameters -Settings $settings
        try
        {
            $maskedParams = ($params | ConvertTo-Json -Depth 6) -replace '"AppPoolPassword"\s*:\s*".*?"', '"AppPoolPassword":"***"'
            Write-Verbose ("DSC parameters:`n{0}" -f $maskedParams)
        }
        catch { Write-Verbose 'Unable to serialise DSC parameters for verbose output.' }

        $result = InvokeDSCDocument -DocumentPath $templatePath -Parameters $params -TestOnly:$TestOnly
        Write-Verbose ('DSC invocation result: {0}' -f ($result | ConvertTo-Json -Depth 3))
    }
    finally
    {
        # No temporary files to clean up when using template files directly.
    }

    Write-Host ''
    WriteStatus 'Deployment complete.' -Status 'OK' -Color Green
}
end
{

}